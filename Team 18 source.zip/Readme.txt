Drive_Car program handles receiving movement commands and physically moving car.
Kinect_Car handles reading gestures from Kinect camera and sends them via Wi-Fi.
To execute, open solution Kinect_Car and build project Kinect_Car.
Program will open window for rendering user skeleton with Kinect but will obviously not render anything since Kinect camera is not connected and RC car is not connected via Wi-Fi.